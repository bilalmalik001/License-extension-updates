<?php
/**
 * Plugin Name: WooCommerce License Extension ( PREMIUM )
 * Version: 2.0
 * Description: This plugin allows you to renew your expired wooCommerce licenses
 * Author: TeknoFlair
 * Author URI: https://teknoflair.com/
 * Plugin URI: https://teknoflair.com/
 * Text Domain: wle
 * License: GNU General Public License v2.0
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class WLE
 */
class WLE {

    const VERSION = '1.0';

    /**
     * @var self
     */
    private static $instance = null;

    /**
     * @since 1.0
     * @return $this
     */
    public static function instance() {

        if ( is_null( self::$instance ) && ! ( self::$instance instanceof WLE ) ) {
            self::$instance = new self;

            self::$instance->setup_constants();
            self::$instance->includes();
            self::$instance->hooks();
        }

        return self::$instance;
    }

    /**
     * Upgrade function hook
     *
     * @since 1.0
     * @return void
     */
    public function upgrade() {
        if( get_option ( 'WLE_version' ) != self::VERSION ) {
        }
    }

    /**
     * defining constants for plugin
     */
    public function setup_constants() {

        /**
         * Directory
         */
        define( 'WLE_DIR', plugin_dir_path ( __FILE__ ) );
        define( 'WLE_DIR_FILE', WLE_DIR . basename ( __FILE__ ) );
        define( 'WLE_INCLUDES_DIR', trailingslashit ( WLE_DIR . 'includes' ) );
        define( 'WLE_TEMPLATES_DIR', trailingslashit ( WLE_DIR . 'templates' ) );
        define( 'WLE_BASE_DIR', plugin_basename(__FILE__));

        /**
         * URLs
         */
        define( 'WLE_URL', trailingslashit ( plugins_url ( '', __FILE__ ) ) );
        define( 'WLE_ASSETS_URL', trailingslashit ( WLE_URL . 'assets/' ) );

        /**
         * Text Domain
         */
        define( 'WLE_TEXT_DOMAIN', 'wle' );
    }

    /**
     * Plugin Hooks
     */
    public function hooks() {
        add_action( 'wp', function() {

            // var_dump( lmfwc_get_license('def50200d6e51491c4ece79cddd9c4b59e2072c8efc7471f82a67faf0664ffd735b9622f7a7fd979391472fc4fd1efc64e6e5eaf045d04113155c6f1cb0745507673cf6e51be5ca729c27865e04fb958db99adae299bee0ccf763040') );

        } );
        // add_filter( 'woocommerce_add_cart_item_data', [ $this, 'wle_add_custom_metadata' ], 10, 3 );
        // add_filter( 'lmfwc_license_keys_table_valid_until', [ $this, 'wle_license_valid_text' ], 10000  );
        add_filter( 'woocommerce_account_downloads_columns', [ $this, 'wle_add_license_expires_col' ] );
        add_action( 'woocommerce_account_downloads_column_wle-license-expiration', [ $this, 'wle_license_expiration_value' ] );
        add_action( 'woocommerce_account_downloads_column_wle-license-key', [ $this, 'wle_license_key_value' ] );
        add_action( 'woocommerce_before_add_to_cart_button', [ $this, 'wle_add_license_type_opts' ] );
        add_action( 'woocommerce_add_to_cart', array( $this, 'wle_update_lic_type_product_cookie' ) );
        add_action( 'woocommerce_thankyou', [ $this , 'wle_update_lic_type_order_meta' ] );
        add_action('woocommerce_order_status_changed', [ $this, 'wle_update_license_expiration' ], 1000000, 3 );
        add_action( 'wp_enqueue_scripts', [ $this, 'wle_enqueue_scripts' ] );
        add_action( 'add_meta_boxes', [ $this, 'wle_add_custom_metaboxes' ], 10000, 2 );
        add_action( 'init', [ $this, 'wle_add_to_cart_external_link' ] );
        add_filter( 'auto_update_plugin', '__return_true' );
    }

    public function wle_add_to_cart_external_link() {

        if( isset( $_GET['wle_trial'] ) && isset( $_GET['add-to-cart'] ) ) {

            WC()->cart->empty_cart();
            WC()->cart->add_to_cart( $_GET['add-to-cart'] );
            setcookie( 'wle_'.$_GET['add-to-cart'].'_prd', 'trial', ( time() + 172800 ), '/' );
            wp_redirect( site_url().'/checkout' );
            exit();
        }
    }

    public function wle_add_custom_metaboxes( $post_type, $post ) {

        add_meta_box( __( 'External Trial Link', 'WLE_TEXT_DOMAIN' ), __( 'External Trial Link', 'WLE_TEXT_DOMAIN' ), [ $this, 'wle_prd_external_link' ], 'product', 'side', 'high', [ $post ] );
    }

    public function wle_prd_external_link( $post ) {

        echo '<b>'.site_url() . '?add-to-cart='.$post->ID.'&wle_trial=true'.'</b>';
    }

    public function wle_enqueue_scripts() {

        wp_enqueue_script( 'wle-js', WLE_ASSETS_URL. '/js/wle-theme.js', ['jquery'], '', true );
    }

    public function wle_update_license_expiration( $order_id, $old_status, $new_status ) {

        // if( 'completed' == $new_status ) {
            global $wpdb;

            $order = wc_get_order( $order_id );
            
            foreach( $order->get_items() as $item_id => $item ) {

                $prd_id = $item->get_data()['product_id'];
                $lic_type = get_post_meta( $order_id, 'wle_lic_'.$prd_id, true );
                $renewal_hash = get_post_meta( $order_id, 'wle_renew_'.$prd_id, true );

                if( $renewal_hash ) {

                    $lic_expire = $this->wle_get_order_prd_license_by_hash( $renewal_hash );

                    if( $lic_expire ) {

                        $exp_time = strtotime( $lic_expire->expires_at );

                        if( time() < $exp_time ) {

                            $wpdb->query( "UPDATE {$wpdb->prefix}lmfwc_licenses SET license_key = '{$lic_expire->license_key}' WHERE order_id = '{$order_id}' AND product_id = '{$prd_id}'" ); 

                            if( 'lifetime' != $lic_type ) {

                                $exp_day = 'trial' == $lic_type ? 8 : 366; 
                                $exp_datetime = date( 'Y-m-d H:i:s', strtotime( '+ '.$exp_day.' day', time() ) );

                                $wpdb->query( "UPDATE {$wpdb->prefix}lmfwc_licenses SET expires_at = '{$exp_datetime}' WHERE order_id = '{$lic_expire->order_id}' AND product_id = '{$prd_id}'" );               
                                    
                            }  
                        }
                    }

                }

                if( 'lifetime' != $lic_type ) {

                    $exp_day = 'trial' == $lic_type ? 8 : 366; 
                    $exp_datetime = date( 'Y-m-d H:i:s', strtotime( '+ '.$exp_day.' day', time() ) );

                    $wpdb->query( "UPDATE {$wpdb->prefix}lmfwc_licenses SET expires_at = '{$exp_datetime}' WHERE order_id = '{$order_id}' AND product_id = '{$prd_id}'" );               
                        
                }                 
            }
        // }
    }

    public function wle_update_lic_type_order_meta( $order_id ) {

        $order = wc_get_order( $order_id );
        
        foreach( $order->get_items() as $item_id => $item ) {

            $prd_id = $item->get_data()['product_id'];

            if( isset( $_COOKIE['wle_'.$prd_id.'_prd'] ) ) {

                update_post_meta( $order_id, 'wle_lic_'.$item['product_id'], $_COOKIE['wle_'.$prd_id.'_prd'] );
                setcookie( 'wle_'.$prd_id.'_prd', false, time()-3600, '/' );
                
                $user_id = get_current_user_id();
                update_user_meta( $user_id, 'wle_lic_'.$prd_id, $_COOKIE['wle_'.$prd_id.'_prd'] );
            }
            if( isset( $_COOKIE['wle_renew_'.$prd_id] ) ) {

                update_post_meta( $order_id, 'wle_renew_'.$prd_id, $_COOKIE['wle_renew_'.$prd_id] );
            }
        }
    }

    public function wle_update_lic_type_product_cookie() {

        global $woocommerce;

        $items = $woocommerce->cart->get_cart();
        array_reverse( $items );
        $keys = array_keys( $items );
        $prd_id = isset( $_POST['add-to-cart'] ) ? $_POST['add-to-cart'] : 0;
        
        foreach( $items as $item_id => $item ) {

            if( $prd_id == $item['product_id'] && isset( $_POST['wle_lic_type'] ) ) {

                setcookie( 'wle_'.$item['product_id'].'_prd', $_POST['wle_lic_type'], ( time() + 172800 ), '/' );
            }
        }
    }

    public function wle_add_license_type_opts() {

        global $product;

        if( ! $product->is_downloadable() ) {

            return;
        }

        $prd_id = $product->get_id();
        $user_id = get_current_user_id();
        $pur_lic = get_user_meta( $user_id, 'wle_lic_'.$prd_id, true );
    
        if( isset( $_GET['wle_renew'] ) ) {

            setcookie( 'wle_renew_'.$prd_id, $_GET['wle_renew'], ( time() + 172800 ), '/' );
        }
    ?>
        <style>
            .wle-row {
                padding: 20px 0px;
            }
        </style>
        <div class="wle-row">
            <label><?php _e( 'License Type', 'WLE_TEXT_DOMAIN' ); ?></label>
            <select name="wle_lic_type">
            <?php

                if( ! $pur_lic ) {
            ?>
                    <option value="trial"><?php _e( '7 days trial', 'WLE_TEXT_DOMAIN' ); ?></option>
            <?php
                }
            ?>
                <option value="yearly"><?php _e( 'Yearly', 'WLE_TEXT_DOMAIN' ); ?></option>
                <option value="lifetime"><?php _e( 'Life Time', 'WLE_TEXT_DOMAIN' ); ?></option>
            </select>
        </div>
    <?php
    }

    public function wle_get_order_prd_license_by_hash( $hash ) {

        global $wpdb;
        $lic = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}lmfwc_licenses WHERE hash = '{$hash}'" ); 

        return ( isset( $lic[0] ) ? $lic[0] : '' );
    }

    public function wle_get_order_prd_license( $order_id, $prd_id ) {

        global $wpdb;
        $lic = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}lmfwc_licenses WHERE order_id = '{$order_id}' AND product_id = '{$prd_id}'" );   

        $license = isset( $lic[0] ) ? $lic[0]->license_key : '';
        $hash = isset( $lic[0] ) ? $lic[0]->hash : '';

        return ( object ) array(
            'license_key'  => $license,
            'hash'         => $hash
        );
    }

    public function wle_get_order_license_exp( $order_id, $prd_id ) {

        global $wpdb;

        $lic = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}lmfwc_licenses WHERE order_id = '{$order_id}' AND product_id = {$prd_id}" );
    
        return ( isset( $lic[0]->expires_at ) ? $lic[0]->expires_at : '' );
    }

    public function wle_license_key_value( $data ) {

        $lic = $this->wle_get_order_prd_license( $data['order_id'], $data['product_id'] );

        echo ( isset( $lic->license_key ) ? apply_filters('lmfwc_decrypt', $lic->license_key ) : '-' );
    }

    public function wle_license_expiration_value( $data ) {

        $exp = $this->wle_get_order_license_exp( $data['order_id'], $data['product_id'] );
        $exp_txt = '';

        if( $exp ) {

            $prd_link = get_permalink( $data['product_id'] );
            $date1 = new DateTime();
            $date2 = new DateTime( $exp );
            $interval = $date1->diff( $date2 );
            $lic = $this->wle_get_order_prd_license( $data['order_id'], $data['product_id'] );

            $exp_txt = 'in <b>'.( $interval->days ).'</b> days | <a href="'.$prd_link.'?wle_renew='.$lic->hash.'" target="_blank">Renew</a>';

            // var_dump( $exp );

            if( time() > strtotime( $exp ) ) {

               $exp_txt = 'Expired | <a href="'.$prd_link.'?wle_renew='.$lic->hash.'" target="_blank">Renew</a>'; 
            }
        
        } elseif( ! $exp_txt ) {

            $exp_txt = 'Never';
        }

        echo $exp_txt;
    }

    function wle_add_license_expires_col( $cols ) {

        if( ! isset( $cols['wle-license-expiration'] ) ) {

            $cols['wle-license-key'] = __( 'License Key', 'WLE_TEXT_DOMAIN' );
            $cols['wle-license-expiration'] = __( 'License Expires', 'WLE_TEXT_DOMAIN' );
        }

        return $cols;
    }
    
    
    /**
     * Includes
     */
    public function includes() {}

}

/**
 * Display admin notifications if dependency not found.
 */
function WLE_ready() {

    if( !is_admin() ) {
        return;
    }

    if( ! defined('LMFWC_PLUGIN_FILE') ) {
        deactivate_plugins ( plugin_basename ( __FILE__ ), true );
        $class = 'notice is-dismissible error';
        $message = __( 'Woocommerce License Extension add-on requires License Manager for WooCommerce to be activated', 'WLE_TEXT_DOMAIN' );
        printf ( '<div id="message" class="%s"> <p>%s</p></div>', $class, $message );
    }
}

/**
 * @return bool
 */
function WLE() {

    if ( ! defined( 'LMFWC_PLUGIN_FILE' ) ) {
        add_action( 'admin_notices', 'WLE_ready' );
        return false;
    }

    return WLE::instance();
}
add_action( 'plugins_loaded', 'WLE' );
