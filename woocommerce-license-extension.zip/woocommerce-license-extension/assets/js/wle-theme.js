( function( $ ) { 'use strict';

	$( document ).ready( function() {

		let WLE = {

			init: function() {

				this.addRenewButton();
			},

			addRenewButton: function() {


				// if( $( '.lmfwc-myaccount-license-key:last' ).length > 0 && $( '.wle-rn-btn' ).length <= 0 ) {

				// 	$( '.lmfwc-myaccount-license-key:last' ).parents( 'td' ).after( '<td class="wle-rn-btn"><a href="">Renew</a></td>' );
				// }
			}
		};

		WLE.init();

	} );

} )( jQuery );